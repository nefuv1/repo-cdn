# Kumpulan-script
Script bot 
